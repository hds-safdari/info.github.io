---
layout: default
title: Home
description: Interdisciplinary physicist working on statistical physics, probabilistic modeling, complex networks, and machine learning.
---

<section class="hero">
  <div>
    <p class="eyebrow">Interdisciplinary physicist</p>
    <h1>Modeling hidden structure in complex systems.</h1>
    <p class="lede">
      I build probabilistic and interpretable models for complex, noisy, and evolving data — from social and information networks to dynamical biological ecosystems.
    </p>

    <div class="tag-row" aria-label="Research areas">
      <span class="tag">Statistical physics</span>
      <span class="tag">Bayesian inference</span>
      <span class="tag">Complex networks</span>
      <span class="tag">Machine learning</span>
      <span class="tag">Microbial dynamics</span>
    </div>

    <div class="hero-actions">
      <a class="button" href="pub.html">Explore projects</a>
      <a class="button secondary" href="Safdari_CV.pdf">Download CV</a>
    </div>

    <div class="social-row" aria-label="Profiles">
      <a class="icon-link" href="https://scholar.google.com/citations?user=H-9OPuIAAAAJ&hl=en">
        <img src="pngwing.png" alt=""> Google Scholar
      </a>
      <a class="icon-link" href="https://linkedin.com/in/hadiseh-safdari-238540153">
        <img src="LinkedIn_logo_initials.png" alt=""> LinkedIn
      </a>
      <a class="icon-link" href="https://github.com/hds-safdari">
        <img src="github-mark.png" alt=""> GitHub
      </a>
    </div>
  </div>

  <figure class="visual-card">
    <img src="microbial_interaction_inference_pipeline.png" alt="Pipeline from noisy time-series data to a Bayesian model and inferred network">
    <figcaption>
      From noisy observations to interpretable models of hidden interactions.
    </figcaption>
  </figure>
</section>

<section class="section">
  <div class="section-header">
    <p class="eyebrow">Research profile</p>
    <h2>Probabilistic models for data that are messy, relational, and dynamic.</h2>
    <p>
      My work sits at the crossroads of statistical physics, probabilistic modeling, and machine learning. I develop generative models that help explain the webs of interaction shaping real-world systems — from the social networks that connect us to the living ecosystems around us.
    </p>
  </div>

  <div class="grid-3">
    <article class="focus-card">
      <h3>Network structure</h3>
      <p>
        I model communities, reciprocity, and anomalous interactions in networks whose structure changes over time.
      </p>
    </article>

    <article class="focus-card">
      <h3>Noisy observations</h3>
      <p>
        I build models that account for missingness, reporting bias, measurement noise, and conflicting observations rather than treating them as afterthoughts.
      </p>
    </article>

    <article class="focus-card">
      <h3>Dynamical systems</h3>
      <p>
        My current work extends this modeling philosophy to biological time series, especially microbial communities responding to changing environments.
      </p>
    </article>
  </div>
</section>

<section class="section">
  <div class="section-header">
    <p class="eyebrow">Selected work</p>
    <h2>Recent and representative projects.</h2>
  </div>

  <div class="project-list">
    <article class="project-card">
      <div>
        <p class="meta">Ongoing · Bayesian modeling · Microbial ecosystems</p>
        <h3>Learning microbial interactions from time-series data</h3>
        <p>
          A Bayesian framework for inferring how microbial species influence one another through time, while incorporating environmental context, measurement noise, and biological interpretability.
        </p>
        <div class="card-actions">
          <a class="button secondary" href="pub.html#microbial-interactions">Read more</a>
        </div>
      </div>
      <img src="microbial_interaction_inference_pipeline.png" alt="Microbial interaction inference pipeline">
    </article>

    <article class="project-card compact">
      <div>
        <p class="meta">Nature Portfolio · Communications Physics · 2024</p>
        <h3>Anomaly detection in dynamic networks — DynACD</h3>
        <p>
          A probabilistic model that learns evolving community structure and detects interactions that deviate from the learned baseline.
        </p>
        <div class="pub-links">
          <a href="https://doi.org/10.1038/s42005-024-01889-y">Paper</a>
          <a href="https://github.com/hds-safdari/DynACD">Code</a>
        </div>
      </div>
    </article>

    <article class="project-card compact">
      <div>
        <p class="meta">JRSS Series A · 2023</p>
        <h3>Inferring social networks from noisy, conflicting reports — VIMuRe</h3>
        <p>
          A latent network model for reconstructing social networks while accounting for reporter reliability, mutuality, and survey noise.
        </p>
        <div class="pub-links">
          <a href="https://doi.org/10.1093/jrsssa/qnac004">Paper</a>
          <a href="https://latentnetworks.github.io/vimure/">Project</a>
        </div>
      </div>
    </article>
  </div>
</section>

<section class="section callout">
  <div>
    <p class="eyebrow">Collaborative science</p>
    <h2>Turning theoretical models into tools for real questions.</h2>
    <p>
      Much of my favorite work has emerged from collaborations with economists, statisticians, biologists, and social scientists. These partnerships challenge me to translate theoretical and computational ideas into answers with real-world impact.
    </p>
    <div class="hero-actions">
      <a class="button secondary" href="pub.html">View projects and publications</a>
    </div>
  </div>
  <img src="microbial_interaction_inference_pipeline.png" alt="Bayesian modeling pipeline">
</section>
