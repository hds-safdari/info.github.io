# Professional GitHub Pages template

## How to install

1. Back up your current repository.
2. Copy the files in this folder into the root of your GitHub Pages repository.
3. Keep your existing figure files in the same root folder, because `pub.md` references these image names:
   - `Genoa_connections_T1.png`
   - `erasmus_example.png`
   - `nicaragua_example_reports.png`
   - `polbooks_hardCD_removing.png`
   - `cell_fate.png`
   - `gameTheory.png`
   - `microbial_interaction_inference_pipeline.png`
4. If your CV has a different filename, edit the `Safdari_CV.pdf` links in `_layouts/default.html` and `index.md`.
5. Commit and push to GitHub.

## Main files

- `_config.yml`: site settings
- `_layouts/default.html`: shared page layout and navigation
- `assets/css/style.css`: visual design
- `index.md`: homepage
- `pub.md`: projects and publications page
